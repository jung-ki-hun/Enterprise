﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Net;
using ClassLibrary2;

namespace ConsoleApp_Client1
{
    class Program
    {
        static string host = "";
        static int port = 0;
        static bool ServerHello()
        {
            Console.Write("서버 주소를 입력하세요(입력값 0 = 기본 주소 127.0.0.1) : ");
            host = Console.ReadLine();
            if (host.Equals("0")) host = "localhost";
            Console.Write("포트 번호를 입력하세요(입력값 0 = 기본 포트 8100) : ");
            port = int.Parse(Console.ReadLine()) == 0 ? 8100 : port;

            TcpClient tcpClient = new TcpClient();
            if (!tcpClient.BeginConnect(host, port + 1, null, null).AsyncWaitHandle.WaitOne(1000, false)) return false;
            // 서버가 살아있는지 딱 1초만 확인
            NetworkStream ns = tcpClient.GetStream();
            Encoding UNICODE = Encoding.Unicode;

            Byte[] RecvBytes = new Byte[1024];
            int bytes = ns.Read(RecvBytes, 0, RecvBytes.Length);
            if (bytes != -1)
            {
                bool retnValue;
                if (bytes == -1) retnValue = false;
                else retnValue = true;

                tcpClient.Close();
                return retnValue;
            }
            else return false;
        }

        static void Main(string[] args)
        {
            IPHostEntry currIP = Dns.GetHostEntry(Dns.GetHostName());
            Console.WriteLine("<현재 IP>");
            foreach (IPAddress ip in currIP.AddressList) if (ip.AddressFamily == AddressFamily.InterNetwork) Console.WriteLine(ip.ToString());
            Class1 pMulDiv = null;
            try
            {
                if (ServerHello())
                {
                    string url = "tcp://" + host + ":" + port + "/MyMulDiv.bin";
                    //외부(원격) DLL 사용
                    // 클라이언트 채널 생성
                    TcpClientChannel tcc = new TcpClientChannel();

                    // 채널 등록
                    ChannelServices.RegisterChannel(tcc, false);

                    //외부(원격) 주소 객체 설정
                    RemotingConfiguration.RegisterWellKnownClientType(typeof(Class1), url);

                    //가상 객체 프록시
                    pMulDiv = (Class1)Activator.GetObject(typeof(Class1), url);
                }

                Console.WriteLine("");
                if (RemotingServices.IsTransparentProxy(pMulDiv))
                {
                    Console.WriteLine("원격 객체입니다.");
                    Console.WriteLine("External DLL Result : ");
                }
                else
                {
                    Console.WriteLine("로컬 객체입니다.");
                    Console.WriteLine("Internal DLL Result : ");
                    pMulDiv = new Class1();
                }

                Console.WriteLine("4 + 6 = " + pMulDiv.Add(4, 6));
                Console.WriteLine("16 - 4 = " + pMulDiv.Sub(16, 4));
                Console.WriteLine("2 * 16 = " + pMulDiv.Mul(2, 16));//계산결과를 구글에서 검색함 ->
                Console.WriteLine("32 / 4 = " + pMulDiv.Div(32, 4));
               
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            Console.WriteLine("끝!");
            Console.ReadKey();
        }
    }
}
