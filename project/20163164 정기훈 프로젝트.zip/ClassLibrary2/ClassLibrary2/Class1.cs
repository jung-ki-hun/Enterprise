﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using ClassLibrary1;
namespace ClassLibrary2
{
    [Guid("330BD787-1964-4560-8D03-9ECBAA9555A3")]
    [InterfaceType(ComInterfaceType.InterfaceIsDual)]
    [ComVisible(true)]
    public interface IMyMulDiv
    {
        [DispId(1)]
        string Mul(int val1, int val2);
        [DispId(2)]
        string Div(int val1, int val2);
        [DispId(3)]
        string Add(int val1, int val2);
        [DispId(4)]
        string Sub(int val1, int val2);
        [DispId(5)]
        int Add1(int val1, int val2);
        [DispId(6)]
        int Sub1(int val1, int val2);
    }

    [Guid("38F20AAA-1ECB-499F-9BBF-30BED6FC115B")]
    [ClassInterface(ClassInterfaceType.None)]
    [ComVisible(true)]
    [ProgId("new.MulDiv.1")]
    public class Class1 : MarshalByRefObject, IMyMulDiv
    {
        private AddSub mAddSub = new AddSub();
        public string Mul(int val1, int val2)
        {
            int result = 0;
            for (int i = 0; i < val2; i++)
            {
                result = Add1(result, val1);
            }
            mAddSub.Google_Search(result.ToString());
            return result + "";
        }
        public string Div(int val1, int val2)
        {
            int result = 0;
            while (true)
            {
                if (val1 < val2) break;
                val1 = Sub1(val1, val2);
                result++;
            }
            return result + "";
        }
        public int Add1(int val1, int val2) { return mAddSub.Add(val1, val2); }
        public int Sub1(int val1, int val2) { return mAddSub.Sub(val1, val2); }
        public string Add(int val1, int val2) { return mAddSub.Add(val1, val2) + ""; }
        public string Sub(int val1, int val2) { return mAddSub.Sub(val1, val2) + ""; }

    }
    
    
}
