﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.ComponentModel;

namespace ClassLibrary1
{
    [Guid("1B1E9BB7-A80B-47D6-AB1B-70F3E9396822")]
    [InterfaceType(ComInterfaceType.InterfaceIsDual)]
    [ComVisible(true)]
    public interface IAddSub
    {
        [DispId(1)]
        int Add(int val1, int val2);
        [DispId(2)]
        int Sub(int val1, int val2);
        [DispId(3)]
        int Google_Search(string val1);
    }

    [Guid("ADEF6DC9-0FCE-44F9-9BB7-9C3384EE36E9")]
    [ClassInterface(ClassInterfaceType.None)]
    [ComVisible(true)]
    [ProgId("new.AddSub.1")]
    public class AddSub : IAddSub
    {
        public int Add(int val1, int val2) { return val1 + val2; }
        public int Sub(int val1, int val2) { return val1 - val2; }
        public int Google_Search(string val1) { Process.Start("https://www.google.com/search?q="+val1);
            return 0;
        }
    }
   
}
