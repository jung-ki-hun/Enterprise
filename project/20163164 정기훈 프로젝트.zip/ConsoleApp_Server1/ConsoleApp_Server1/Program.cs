﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using System.Threading;
using ClassLibrary2;

namespace ConsoleApp_Server1
{
    class Program
    {
        static int port = 8100;
        static void Main(string[] args)
        {
            //서버 채널 생성
            TcpServerChannel tsc = new TcpServerChannel(port);
            //서버 채널 등록
            ChannelServices.RegisterChannel(tsc, false);
            //원격 객체 준비
            RemotingConfiguration.RegisterWellKnownServiceType(typeof(Class1), "MyMulDiv.bin", WellKnownObjectMode.Singleton);
            RemotingConfiguration.CustomErrorsMode = System.Runtime.Remoting.CustomErrorsModes.Off;

            TcpListener tcpListener = new TcpListener(IPAddress.Any, port + 1);
            TcpClient client = new TcpClient();

            tcpListener.Start();
            Console.WriteLine("[TCP 서버] 서버가 시작되었습니다.");
            try
            {
                while (true)
                {
                    client = tcpListener.AcceptTcpClient();
                    if (client.Connected)
                    {
                        Socket s = client.Client;
                        string address = s.RemoteEndPoint.ToString();
                        string[] array = address.Split(new char[] { ':' });
                        NetworkStream ns = client.GetStream();
                        Encoding UNICODE = Encoding.Unicode;

                        Console.WriteLine("[TCP 서버] 클라이언트 응답 : IP 주소 = " + array[0] + " 포트번호 = " + array[1]);
                        byte[] tmpByte = UNICODE.GetBytes("Client Hello");

                        ns.Write(tmpByte, 0, tmpByte.Length);
                        Console.WriteLine("[TCP 서버] 클라이언트 연결 해제 : IP 주소 = " + array[0] + " 포트번호 = " + array[1]);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception Thrown : " + e.ToString());
                Console.WriteLine("[TCP 서버] 서버가 닫혔습니다..");
                Console.ReadKey();
            }
            finally
            {
                client.Close();
            }
        }
    }
}
