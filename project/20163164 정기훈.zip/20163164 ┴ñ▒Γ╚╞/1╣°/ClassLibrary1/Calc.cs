﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.IO;

namespace ClassLibrary1
{
    [Guid("9E5E5FB2-219D-4ee7-AB27-E4DBED8E123E"),
   ClassInterface(ClassInterfaceType.None),
   ComSourceInterfaces(typeof(DBCOM_Events))]
    public class Calc : ICalc
    {

        public Calc()
        {

        }


        public int sum(int val1, int val2)
        {
            return val1 + val2;
        }

        public int sub(int val1, int val2)
        {
            return val1 + val2;
        }

        public int mul(int val1, int val2)
        {

            return val1 + val2;
        }

        public double div(int val1, int val2)
        {
            return val1 / val2;
        }
    }
}
