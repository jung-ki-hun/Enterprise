﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.InteropServices;

namespace ClassLibrary1
{
    [Guid("694C1820-04B6-4988-928F-FD858B95C880")]
    interface ICalc
    {
        [DispId(1)]
        int sum(int val1, int val2);
        [DispId(2)]
        int sub(int val1, int val2);
        [DispId(3)]
        int mul(int val1, int val2);
        [DispId(4)]
        double div(int val1, int val2);
    }
    [Guid("47C976E0-C208-4740-AC42-41212D3C34F0"),
   InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    public interface DBCOM_Events
    {
    }

}
